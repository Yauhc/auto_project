# -*- coding: utf-8 -*-
import os
import requests

def download_file(url, save_dir, filename=None):
    """
    Download a file to the local directory.
    :param url: https://download-cdn.jetbrains.com/idea/ideaIU-2025.1.exe
    :param save_dir: Z:\\projects\\auto_project\\download\\downloads
    :param filename: 
    """
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    
    # If no filename is specified, extract it from the URL
    if not filename:
        filename = url.split("/")[-1]
    
    file_path = os.path.join(save_dir, filename)
    
    try:
        print(f"Downloading {url} to {file_path}...")
        response = requests.get(url, stream=True)
        response.raise_for_status()  # Check if the request was successful
        
        with open(file_path, "wb") as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)
        
        print(f"Download completed: {file_path}")
    except Exception as e:
        print(f"Download failed: {e}")

# Example usage
if __name__ == "__main__":
    url = "https://download-cdn.jetbrains.com/idea/ideaIU-2025.1.exe"  # Replace with your download link
    save_dir = "Z:\\projects\\auto_project\\download\\downloads"  # Replace with your save directory
    download_file(url, save_dir)