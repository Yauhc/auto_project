#define FILEVER 333,039,0,0
#define STRFILEVER "333.039.0.0"
#define STRORIGINALFILENAME "emmcdl.exe"
#define STRCOMPANYNAME "QUALCOMM Incorporated"
#define STRLEGALCOPYRIGHT "Copyright (C) 2012 QUALCOMM Incorporated. All rights reserved."
#define STRPRODUCTNAME "QUALCOMM Windows on Snapdragon"
